let totalCalories = 0; 


function openFoodPopup() {
    let foodPopup = document.getElementById("food-popup");
    foodPopup.style.visibility = "visible";
}

function addFoodEntry() {
    let foodName = document.getElementById("foodName").value;
    let serving = document.getElementById("serving").value;
    let caloriesInput = document.getElementById("calories");

 
    let calories = parseFloat(caloriesInput.value);
    if (isNaN(calories)) {
        alert("Please enter a valid number for calories.");
        return;
    }

    let newEntry = document.createElement("div");

    newEntry.classList.add("entry");

    newEntry.innerHTML = `<p>${foodName}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;${serving}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ${calories} kcal</p>`;

    document.getElementById("entries").appendChild(newEntry);

     totalCalories += calories;
     document.getElementById("total").innerText = `Total: ${totalCalories} Calories`;

    document.getElementById("foodForm").reset();
    closeFoodPopup();
}

function closeFoodPopup() {
    let foodPopup = document.getElementById("food-popup");
    foodPopup.classList.remove("open-popup");
    foodPopup.style.visibility = "hidden";
}












function openExercisePopup() {
    let exercisePopup = document.getElementById("exercise-popup");
    exercisePopup.style.visibility = "visible";
}

function addExerciseEntry() {
    let exerciseName = document.getElementById("exerciseName").value;
    let time = document.getElementById("time").value;
    let caloriesBurntInput = document.getElementById("caloriesBurnt");

    let caloriess = parseFloat(caloriesBurntInput.value);
    if (isNaN(caloriess)) {
        alert("Please enter a valid number for calories.");
        return;
    }

    let newEntry = document.createElement("div");

    newEntry.classList.add("entry");

    newEntry.innerHTML = `<p>${exerciseName}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;${time}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ${caloriess} ckal</p>`;

    document.getElementById("entries").appendChild(newEntry);

    totalCalories -= caloriess;
    document.getElementById("total").innerText = `Total: ${totalCalories} Calories`;

   

    document.getElementById("exerciseForm").reset();
    closeExercisePopup();
}

function closeExercisePopup() {
    let exercisePopup = document.getElementById("exercise-popup");
    exercisePopup.classList.remove("open-popup");
    exercisePopup.style.visibility = "hidden";
}





let userDetails = {
    name: "",
    height: "",
    weight: "",
    age: ""
};



function closePopup() {
    console.log('Hello');
    let popup = document.getElementById("cont");
    let cont = document.getElementById("cont");

    cont.classList.remove("cont");
    cont.style.visibility = "hidden";
    cont.classList.add("open-popup");  
    

   
    userDetails.name = document.getElementById("name").value;
    userDetails.height = document.getElementById("height").value;
    userDetails.weight = document.getElementById("weight").value;
    userDetails.age = document.getElementById("age").value;

    document.getElementById("user-name").innerText = userDetails.name;
    document.getElementById("Height").innerText = `Height: ${userDetails.height}`;
    document.getElementById("Weight").innerText = `Weight: ${userDetails.weight}`;
    document.getElementById("Age").innerText = `Age: ${userDetails.age}`;
}
